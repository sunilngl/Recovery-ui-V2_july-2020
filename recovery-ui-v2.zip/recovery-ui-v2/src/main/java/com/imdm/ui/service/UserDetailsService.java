package com.imdm.ui.service;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;

import com.imdm.ui.controller.RecoveryController;
import com.imdm.ui.ldap.CustomLdapUserDetails;

public class UserDetailsService extends LdapUserDetailsMapper {

	private final Log logger = LogFactory.getLog(UserDetailsService.class);
 	private String displayName = "displayname";
 	
    public UserDetailsService() {
    }

    public UserDetails mapUserFromContext(DirContextOperations ctx, String username, Collection<? extends GrantedAuthority> authorities) {
        UserDetails details = super.mapUserFromContext(ctx, username, authorities);
        CustomLdapUserDetails customLdapUserDetails = new CustomLdapUserDetails((LdapUserDetails) details);

        customLdapUserDetails.setDisplayName(ctx.getStringAttribute(displayName));
        
       RecoveryController.setDisplayName(customLdapUserDetails.getDisplayName());
        return customLdapUserDetails;
    }
     
}

