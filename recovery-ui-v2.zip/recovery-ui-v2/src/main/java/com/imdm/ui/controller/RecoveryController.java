package com.imdm.ui.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.imdm.ui.model.FileInfo;
import com.imdm.ui.model.ResponseMessage;
import com.imdm.ui.service.FilesStorageService;



//@CrossOrigin(origins="http://localhost:4200")
@RestController
public class RecoveryController {

	
		private static String displayName;
		private String recoveryStatus="NA";
		
		
		public static void setDisplayName(String name) {
			displayName=name;
		}
		
		
		@RequestMapping(value = "/displayname",method = RequestMethod.GET)
		public String getDisplayName() {
			
			return displayName;
		}
		
		@PostMapping(value = "/cdb")
		public String resulttwo(@RequestParam("srccode") String sourceCode, @RequestParam("recordval") String memberId,HttpServletRequest httRequest) {
			HttpSession session = httRequest.getSession();
			session.setAttribute("username",displayName);
			
			Model model = null;
			String resp=null;
			String id = sourceCode+"|"+memberId;
			try {
			    String url = "http://imdm-rec-individualmdm.origin-ctc-core.optum.com/api/recovery/"+id;
			    String authStr = "imdmcicd:cal6Velo";
			    String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());
			    HttpHeaders headers = new HttpHeaders();
			    headers.add("Authorization", "Basic " + base64Creds);
			    HttpEntity request = new HttpEntity(headers);
			    ResponseEntity<String> response = new RestTemplate().exchange(url, HttpMethod.GET, request, String.class);
			    String json = response.getBody();
			    resp = "Request has been Submitted Sucessfully";
			    recoveryStatus = "Request has been Submitted Sucessfully";
				//model.addAttribute("msg", "Request has been submitted successfully.");
			} catch (Exception ex) {
			    ex.printStackTrace();
			    //model.addAttribute("msg", "Something went wrong !!.");
			    resp = "Something went wrong !!.";
			    recoveryStatus = "Something went wrong !!.";
			}
			ModelAndView view = new ModelAndView(); 
			//view.setViewName("cdbView");
			String[] src = sourceCode.split("_");
			if(src.length > 1) {
				//model.addAttribute("src", "cdb");
			}else {
				//model.addAttribute("src", sourceCode);
			}
			//model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			return resp;
		}
		
		
		@RequestMapping(value = "/welcome", method = RequestMethod.GET)
		public ModelAndView welcome(HttpServletRequest httpRequest,HttpServletResponse httpResponse) throws IOException {
			Map<String,String> mapwelcom = new HashMap<String, String>();
			mapwelcom.put("welcome","Welcome");
			mapwelcom.put("displayname", displayName);
			httpResponse.setHeader("Access-Control-Allow-Origin", "*");
			//redirectStrategy.sendRedirect(httpRequest, httpResponse, "/welcome");
			ModelAndView view = new ModelAndView();
			view.setViewName("welcome");
			//httpResponse.sendRedirect("/login");
			return view;
		}
		
		@RequestMapping(value = "/loginresult", method = RequestMethod.GET)
		public Map<String,String> loginresult(HttpServletRequest httpRequest,HttpServletResponse httpResponse) throws IOException {
			Map<String,String> map = new HashMap<String, String>();
			map.put("userid",displayName);
			map.put("displayname", displayName);
			return map;
		}
		
		@Autowired
		  FilesStorageService storageService;

		  @PostMapping("/upload")
		  public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
		    String message = "";
		    try {
		      storageService.save(file);

		      message = "Uploaded the file successfully: " + file.getOriginalFilename();
		      return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		    } catch (Exception e) {
		      message = "Could not upload the file: " + file.getOriginalFilename() + "!";
		      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
		    }
		  }

		  @GetMapping("/files")
		  public ResponseEntity<List<FileInfo>> getListFiles() {
		    List<FileInfo> fileInfos = storageService.loadAll().map(path -> {
		      String filename = path.getFileName().toString();
		      String url = MvcUriComponentsBuilder
		          .fromMethodName(RecoveryController.class, "getFile", path.getFileName().toString()).build().toString();

		      return new FileInfo(filename, url);
		    }).collect(Collectors.toList());

		    return ResponseEntity.status(HttpStatus.OK).body(fileInfos);
		  }

		  @GetMapping("/files/{filename:.+}")
		  @ResponseBody
		  public ResponseEntity<Resource> getFile(@PathVariable String filename) {
		    Resource file = storageService.load(filename);
		    return ResponseEntity.ok()
		        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"").body(file);
		  }

		
		@RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
		public String logoutDo(HttpServletRequest request,HttpServletResponse response){
		HttpSession session= request.getSession(false);
		    SecurityContextHolder.clearContext();
		         session= request.getSession(false);
		        if(session != null) {
		            session.invalidate();
		        }
		        for(Cookie cookie : request.getCookies()) {
		            cookie.setMaxAge(0);
		        }

		    return "logout";
		}
		
		
		
		@RequestMapping(value = "/login", method = RequestMethod.GET)
		public ModelAndView login(@RequestParam(value = "error",required = false) String error,
		@RequestParam(value = "logout",	required = false) String logout,@RequestParam(value = "success",required = false) String success,
		HttpServletRequest httpRequest,HttpServletResponse httpResponse) throws IOException {
			Map<String,String> map = new HashMap<String, String>();
			String response = null;
			boolean isLoginClicksOnURL = true;
			if (error != null) {
				response = "Bad Credentials";
				map.put("badcredentials",response);
				System.out.print("error");
				isLoginClicksOnURL = false;
			}
			if (logout != null) {
				response = "You have been logout successfully";
				map.put("logout",response);
				System.out.print("logout");
				isLoginClicksOnURL = false;
			}
			
			if(success != null) {
				response = "success";
				map.put("success",response);
				
				System.out.print("success");
				isLoginClicksOnURL=false;
			}
			map.put("userid", "sunil");
			//map.put("displayname", displayName);
			map.put("displayname", "Sunil Nagula - TEST NAME");
			
			
			
			
			/*if(isLoginClicksOnURL) {
				httpResponse.sendRedirect(httpRequest.getContextPath()+"welcome");
			}*/
			ModelAndView view = new ModelAndView();
			view.setViewName("/static/index.html");
			
			return view;
		}


		
}
